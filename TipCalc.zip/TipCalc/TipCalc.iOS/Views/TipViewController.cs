﻿using Foundation;
using System.Drawing;
using UIKit;
using TipCalc.Core.ViewModels;
using MvvmCross.Platforms.Ios.Views;

namespace TipCalc.iOS.Views
{
    [Register(nameof(TipViewController))]
    public class TipViewController : MvxViewController<TipViewModel>
    {
        UILabel SubTotal, Generosity, TipLabel, Tip;
        UITextField SubTotalTextField;
        UISlider GenerositySlider;
        UIView _UIView;
        
        protected void CreateView()
        {
            SubTotal = new UILabel();
            SubTotal.Text = "SubTotal";
            Generosity = new UILabel();
            Generosity.Text = "Generosity";
            TipLabel = new UILabel();
            TipLabel.Text = "Tip";
            Tip = new UILabel();
            Tip.Text = "0";

            SubTotalTextField = new UITextField();
            GenerositySlider = new UISlider();
            GenerositySlider.MaxValue = 100;

            _UIView = new UIView();
            _UIView.AddSubviews(SubTotal, Generosity, TipLabel, Tip, SubTotalTextField, GenerositySlider);
            View.AddSubview(_UIView);
        }

        public TipViewController() : base(nameof(TipViewController), null)
        {
        }

       /* public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            CreateView();
            var set = CreateBindingSet();
            set.Bind(TipLabel).To(vm => vm.Tip);
            set.Bind(SubTotalTextField).To(vm => vm.SubTotal);
            set.Bind(GenerositySlider).To(vm => vm.Generosity);
            set.Apply();

            // this is optional. What this code does is to close the keyboard whenever you 
            // tap on the screen, outside the bounds of the TextField
            View.AddGestureRecognizer(new UITapGestureRecognizer(() =>
            {
                this.SubTotalTextField.ResignFirstResponder();
            }));
        } */
    }
}